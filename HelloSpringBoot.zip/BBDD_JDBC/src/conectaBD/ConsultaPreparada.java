package conectaBD;

import java.sql.*;
public class ConsultaPreparada {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//1.Crear conexion
		try {
			Connection miConexion=DriverManager.getConnection("jdbc:mysql://localhost:3306/pruebas","root","holamundo");
		
		//2.preparar consulta
			PreparedStatement miSentencia=miConexion.prepareStatement("SELECT nombre,precio,cantidad FROM PRODUCTOS WHERE codigo=?;");
		//3.Establecer paramteros de consulta
			miSentencia.setInt(1,333);
		//4.Ejecutar y recorrer consulta
			//crar objeto result set
			ResultSet rs=miSentencia.executeQuery(); 
			while(rs.next()) {
				System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3));
			}
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

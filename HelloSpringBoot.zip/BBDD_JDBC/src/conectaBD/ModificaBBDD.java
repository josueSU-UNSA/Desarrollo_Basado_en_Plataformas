package conectaBD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ModificaBBDD {

	public static void main	(String[] args) {
		// TODO Auto-generated method stub
		try {
			//aqui se creara la conexion
		//1.CREAR CONEXION
			Connection miConexion=DriverManager.getConnection("jdbc:mysql://localhost:3306/pruebas","root","holamundo");
			//Connection miConexion=DriverManager.getConnection("jdbc:mysql://localhost:3306/unsa_horarios","root","holamundo");
		//2.CREAR OBJETO STATEMENT
			Statement miStatement=miConexion.createStatement();
		//INSERT REGISTROS EN LA TABLA productos
			String instruccionSql="INSERT INTO PRODUCTOS(codigo,nombre,precio,cantidad) VALUES(477,'camote','9','3')";
			//String instruccionSql2="DELETE FROM productos WHERE (`codigo` = 777)";
			miStatement.executeUpdate(instruccionSql);
			//miStatement.executeUpdate(instruccionSql2);
			System.out.println("Datos insertados correctamente");
		}catch(Exception e) {
			
			//SI HAY UN ERROR CON LA CONEXION ENTONCES ENVIARA UN MENSAJE
			System.out.println("NO CONECTA");
			e.printStackTrace();
		}
	} 

	}



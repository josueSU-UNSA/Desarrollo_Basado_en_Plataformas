package conectaBD;
import java.sql.*;

public class Conecta_Pruebas {
	public static void main(String[]args) {
		//todo auto generated method stub
		//creamos conexion
		try {
			//aqui se creara la conexion
		//1.CREAR CONEXION
			
			Connection miConexion=DriverManager.getConnection("jdbc:mysql://localhost:3306/pruebas","root","holamundo");
			
			//Connection miConexion=DriverManager.getConnection("jdbc:mysql://localhost:3306/unsa_horarios","root","holamundo");
		//2.CREAR OBJETO STATEMENT
			
			Statement miStatement=miConexion.createStatement();
			
		//3.EJECUTAR INSTRUCCION SQL
			
			ResultSet miResultSet=miStatement.executeQuery("SELECT *FROM PRODUCTOS");
			
			//ResultSet miResultSet=miStatement.executeQuery("SELECTiga una iteracion por columnas
				//System.out.println(miResultSet.getString("seccion")+" "+miResultSet.getString("nombre")+" "+miResultSet.getString("precio"));
				//System.out.println(miResultSet.getString(2)+" "+miResultSet.getString(3)+" "+miResultSet.getString(4));
				//System.out.println(miResultS *FROM horarios");
		//4.RECORRER O LEER RESULTSET
			
			System.out.println("Producto Precio Cantidad");
			
			while(miResultSet.next()) {//el.next es para que set.getString(1)+" "+miResultSet.getString(2));
			
				System.out.println(miResultSet.getString(2)+"\t"+miResultSet.getString(3)+"\t"+miResultSet.getString(4));
			}
		}catch(Exception e) {
			
			//SI HAY UN ERROR CON LA CONEXION ENTONCES ENVIARA UN MENSAJE
			
			System.out.println("NO CONECTA");
			
			e.printStackTrace();
		}
	}

}

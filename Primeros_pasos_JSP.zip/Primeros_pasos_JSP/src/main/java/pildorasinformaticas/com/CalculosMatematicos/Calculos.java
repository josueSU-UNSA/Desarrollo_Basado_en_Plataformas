package pildorasinformaticas.com.CalculosMatematicos;

public class Calculos {//usaremos el estatic para al momento de usarlo en el jsp como expresiones solo tengamos que usar el nombre de la clase y no un objeto o tmbn llamado instancia de la clase
	private static int resultado;//el private y public no tienen un comportamiento solo se le incluye para ver que efectivamente es codigo java
	public static int metodoSuma(int num1,int num2){
		resultado=num1+num2;
		return resultado;
	}
	public static int metodoResta(int num1,int num2){
		resultado=num1-num2;
		return resultado;
	}
	public static int metodoMultiplica(int num1,int num2){
		resultado=num1*num2;
		return resultado;
	}
}

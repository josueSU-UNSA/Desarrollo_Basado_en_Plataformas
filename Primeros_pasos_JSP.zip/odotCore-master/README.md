# odotCore

The code in this repository acts as the core of a simple To Do application. 

It's a little backwards (IMHO), hence the name (odot).

It was intended to accompany the IBM dW Spring Boot Basics tutorial only (https://www.ibm.com/developerworks/library/j-spring-boot-basics-perry/index.html), but I have additional plans in mind for it now.

Enjoy the free code.

--JSP
